# TECHTRACK 3.0 — Technical Report
## EV Range Prediction from Specifications

### Team Voltra | MANIT Bhopal

---

## 1. Executive Summary

This report presents a complete machine-learning solution for predicting electric vehicle driving range (`range_km`) from static vehicle specifications. The solution was built for the TECHTRACK 3.0 ML Case Battle at MANIT Bhopal.

**Key results:**

| Metric | Value |
|---|---|
| **Final Model** | Voting Ensemble (Gradient Boosting + Extra Trees + HistGradientBoosting) |
| **Test MAE** | 9.96 km |
| **Test RMSE** | 13.49 km |
| **Test R²** | 0.9834 |
| **Test Median AE** | 7.81 km |
| **Test MAPE** | 2.53% |
| **CV MAE** | 11.68 ± 2.47 km (10-fold) |
| **CV R²** | 0.9672 ± 0.0195 |
| **Physics plausibility** | 100% of predictions |

---

## 2. Problem Definition

**Task:** Predict the official driving range of an EV given its specifications.

**Type:** Regression (`range_km` in kilometres)

**Key constraint:** `efficiency_wh_per_km` must NOT be used as a model input (it would allow algebraic target reconstruction via `range ≈ kWh × 1000 / efficiency`).

**Dataset:** 478 EV models from 59 brands with battery, performance, dimensional, and categorical specifications.

---

## 3. Dataset Characteristics

| Property | Value |
|---|---|
| Records | 478 |
| Brands | 59 |
| Features | 22 (before engineering) |
| Target | `range_km` (mean ≈ 393 km, std ≈ 103 km) |
| Target range | 135–685 km |

---

## 4. Data Quality Issues Identified

| Issue | Column | Count | Resolution |
|---|---|---|---|
| High missingness | `number_of_cells` | 202 (42%) | Tested via ablation; included with median imputation |
| Missing values | `towing_capacity_kg` | 26 (5.4%) | Median imputation in pipeline |
| Missing values | `torque_nm` | 7 (1.5%) | Median imputation in pipeline |
| Missing value | `fast_charging_power_kw_dc` | 1 | Median imputation in pipeline |
| Non-numeric text | `cargo_volume_l` | 3 "Banana Boxes" | Converted using 72L/box estimate |
| Missing value | `cargo_volume_l` | 1 NaN | Body-type median imputation |
| Missing model name | `model` (firefly) | 1 | Filled with brand name |
| Zero variance | `battery_type` | 478 (all same) | Dropped |
| Near-zero variance | `fast_charge_port` | 476/478 CCS | Dropped |
| Metadata | `source_url` | 478 unique | Dropped (not predictive) |
| Towing zeros | `towing_capacity_kg` | 106 zeros | Kept (legitimate — vehicles that cannot tow) |

---

## 5. Cleaning Strategy

1. **Preserve all rows** — no records deleted; every transformation justified
2. **Banana Boxes conversion** — 1 banana box ≈ 72 litres (industry standard measurement)
3. **Brand casing** — standardised lowercase-only brands to title case
4. **Type enforcement** — `cargo_volume_l` converted from mixed text/numeric to float
5. **Zero-variance removal** — `battery_type`, `fast_charge_port` dropped (no predictive signal)
6. **Metadata removal** — `source_url` dropped (unique per row, metadata only)

---

## 6. EDA Findings

### Key observations driving modelling decisions:

1. **Battery capacity is the dominant predictor** (r ≈ 0.88 with range) — but alone explains only ~77% of variance
2. **Efficiency is algebraically linked** — `kWh × 1000 / efficiency` reconstructs range with r > 0.99, confirming the leakage prohibition is necessary
3. **Top speed and fast charging power correlate strongly** (r ≈ 0.75) — premium EVs with faster charging tend to have larger batteries and thus longer range
4. **Acceleration is inversely correlated** (r ≈ -0.71) — faster 0-100 times correlate with larger batteries
5. **Height is negatively correlated** (r ≈ -0.43) — taller vehicles (vans, SUVs) have worse aerodynamics
6. **Drivetrain matters** — AWD vehicles tend to have higher range (larger batteries) but also higher consumption
7. **SUVs dominate the dataset** (51%) — model must handle this class imbalance

---

## 7. Feature Engineering

11 domain-inspired features created, all with physical interpretations and zero leakage risk:

| Feature | Formula | Physical Meaning |
|---|---|---|
| `battery_per_seat` | kWh / seats | Energy budget per passenger |
| `footprint_m2` | L×W / 1e6 | Ground area (aero proxy) |
| `volume_proxy_m3` | L×W×H / 1e9 | Vehicle volume (mass proxy) |
| `battery_per_volume` | kWh / volume | Energy density vs size |
| `battery_per_footprint` | kWh / footprint | Energy density vs area |
| `torque_per_seat` | Nm / seats | Per-passenger performance |
| `torque_per_volume` | Nm / volume | Power density |
| `aspect_ratio` | L / W | Shape proportions |
| `height_ratio` | H / L | Height relative to length |
| `charging_per_battery` | charge_kW / kWh | C-rate proxy |
| `battery_per_towing` | kWh / (tow+1) | Energy vs towing capability |

---

## 8. Leakage Prevention

Multi-layered defence:

1. **Feature audit table** — every column classified as TARGET / FORBIDDEN / PREDICTOR / METADATA
2. **Automated leakage audit function** — programmatically verifies no forbidden features enter the model
3. **Engineered feature registry** — every feature documents its inputs and leakage risk
4. **Train/test separation** — preprocessing fitted only on training data
5. **Post-save verification** — the final pipeline is tested after saving

**Forbidden list:** `efficiency_wh_per_km`, `range_km`, `source_url`

---

## 9. Model Arena

12+ models tested via 10-fold cross-validation on the training set (382 rows):

| Model | CV MAE (km) | CV R² |
|---|---|---|
| Gradient Boosting | 11.77 | 0.9646 |
| HistGradientBoosting | 12.42 | 0.9626 |
| Extra Trees | 12.97 | 0.9609 |
| XGBoost | 12.66 | 0.9606 |
| Random Forest | 13.39 | 0.9585 |
| LightGBM | 13.58 | 0.9594 |
| Ridge | 18.56 | 0.9153 |
| Linear Regression | 18.70 | 0.9127 |
| Lasso | 18.83 | 0.9129 |
| ElasticNet | 18.87 | 0.9114 |
| Decision Tree | 18.80 | 0.9050 |
| KNN | 17.83 | 0.9113 |
| DummyRegressor | 81.93 | -0.0038 |

**Conclusion:** Tree-based ensemble methods dominate. The DummyRegressor (mean predictor) establishes a baseline MAE of ~82 km — our final model reduces this by 87%.

---

## 10. Feature Ablation

Tested four feature-set configurations to determine optimal inputs:

| Feature Set | CV MAE (km) | CV R² |
|---|---|---|
| Raw specs only | 12.53 | 0.9601 |
| Specs + engineered | 12.60 | 0.9625 |
| Specs + engineered + brand | 12.56 | 0.9624 |
| **Specs + engineered + cells** | **12.38** | **0.9627** |

**Decision:** Including `number_of_cells` (with median imputation for 42% missing) provides marginal but consistent improvement. Brand encoding was excluded to avoid overfitting on 59 sparse categories.

---

## 11. Hyperparameter Tuning

Top 3 models tuned via RandomizedSearchCV (50 iterations, 10-fold CV):

| Model | Best CV MAE | Key Parameters |
|---|---|---|
| Gradient Boosting | 11.76 km | n_estimators=500, max_depth=4, lr=0.1, subsample=0.7 |
| HistGradientBoosting | 12.38 km | max_iter=200, max_depth=5, lr=0.15, max_leaf_nodes=15 |
| Extra Trees | 13.00 km | n_estimators=300, max_features=0.8 |

---

## 12. Ensemble Investigation

| Configuration | CV MAE | CV R² |
|---|---|---|
| Tuned Gradient Boosting | 11.76 | 0.9667 |
| Tuned Extra Trees | 13.00 | 0.9612 |
| Tuned HistGradientBoosting | 12.38 | 0.9630 |
| **Voting Ensemble** | **11.68** | **0.9672** |
| Stacking Ensemble | 11.92 | 0.9658 |

**Decision:** The Voting Ensemble (equal-weight average of 3 tuned models) achieved the lowest CV MAE while maintaining generalization. Stacking added complexity without improvement.

---

## 13. Final Evaluation

Holdout test set (96 rows, untouched during all training and tuning):

| Metric | Value |
|---|---|
| MAE | 9.96 km |
| RMSE | 13.49 km |
| R² | 0.9834 |
| Median AE | 7.81 km |
| MAPE | 2.53% |

### Error Distribution:
- **61.5%** of predictions within 10 km of actual
- **92.7%** within 25 km
- **100%** within 50 km
- Mean absolute error: 9.96 km, std: 9.09 km

### Worst Predictions:
| Vehicle | Actual | Predicted | Error |
|---|---|---|---|
| NIO ET7 Long Range | 505 km | 457.6 km | 47.4 km |
| Hyundai IONIQ 6 LR 2WD | 495 km | 452.5 km | 42.5 km |
| Renault Scenic E-Tech | 480 km | 513.5 km | 33.5 km |

The worst errors occur on vehicles with unusually efficient aerodynamics (IONIQ 6) or atypical battery configurations — information not available in the specification dataset.

---

## 14. Explainability

### Permutation Importance (top 10):

| Feature | Importance (MAE increase) |
|---|---|
| `battery_per_volume` | 56.85 |
| `battery_per_seat` | 9.42 |
| `height_ratio` | 5.36 |
| `battery_capacity_kWh` | 5.17 |
| `battery_per_footprint` | 3.34 |
| `fast_charging_power_kw_dc` | 2.11 |
| `length_mm` | 1.88 |
| `cargo_volume_l` | 1.27 |
| `acceleration_0_100_s` | 1.03 |
| `aspect_ratio` | 0.86 |

`battery_per_volume` dominates — the ratio of battery capacity to vehicle bounding-box volume captures both energy density and vehicle size in a single metric. This makes physical sense: for a given battery, smaller vehicles are more energy-efficient.

### SHAP Analysis:

SHAP values confirm the same ranking. The top SHAP features are `battery_per_volume` (59.85 mean |SHAP|), `battery_per_seat` (17.40), and `height_ratio` (6.62).

---

## 15. Physics Sanity Check

Post-prediction validation using the deliberately excluded `efficiency_wh_per_km`:

- **100%** of test predictions have implied efficiency between 80–400 Wh/km
- Mean implied efficiency error: 19.1%
- No prediction is physically impossible

---

## 16. Interactive System

Streamlit application (`app/app.py`) provides:
- **Manual input mode** — enter any EV specifications with validation
- **Demo presets** — Compact EV / Mid-Size SUV / Premium Sedan
- **Dataset EV mode** — select real EVs from the training data
- **Instant prediction** with physics sanity check
- **Live SHAP explanation** for the current prediction
- **What-if sensitivity analysis** — vary one parameter and see the effect
- **Global feature importance** via permutation importance and SHAP
- **Model methodology tab** — full transparency for judges

---

## 17. Reproducibility

- All random seeds fixed (`42`)
- Single `run_pipeline.py` script reproduces everything
- Pipeline saved as `.joblib` with full metadata
- `requirements.txt` with version constraints
- 38 automated tests across 4 test modules
- No hidden notebook state dependencies

---

## 18. Limitations

1. **Static specifications only** — no real-world driving factors (weather, traffic, HVAC, terrain)
2. **478-row dataset** limits generalisation to novel vehicle designs
3. **Official range values** (WLTP/NEDC) differ from real-world driving range
4. **Missing vehicle weight** and aerodynamic drag coefficient (Cd)
5. Some brands have very few training samples (1–2 models)
6. Test MAE (9.96) < CV MAE (11.68) suggests favourable test split — CV is the more conservative estimate

---

## 19. Future Work

1. Incorporate vehicle weight when available
2. Add aerodynamic drag coefficient (Cd × frontal area)
3. Expand dataset with more EV models as they are released
4. Investigate conformal prediction for calibrated uncertainty intervals
5. Consider separate models for different vehicle classes

---

## 20. Conclusion

We built a technically defensible, reproducible, and explainable EV range prediction system. Every decision — from data cleaning to model selection — is supported by experimental evidence from the supplied dataset. The system achieves R² = 0.9834 on held-out data while maintaining 100% physical plausibility, demonstrating that specification-based range prediction is viable without leaked efficiency data.

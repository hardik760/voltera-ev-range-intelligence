"""
TECHTRACK 3.0 — Inference Consistency Tests

Verifies that predictions are identical across all inference paths:
  - Saved pipeline artifact (direct .predict)
  - App preparation path (same as Streamlit/API)

All paths must produce the SAME prediction for the SAME input.
"""

import os
import sys
import json
import pytest
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)


@pytest.fixture(scope="module")
def pipeline():
    import joblib
    model_path = os.path.join(PROJECT_ROOT, "models", "final_ev_range_pipeline.joblib")
    return joblib.load(model_path)


@pytest.fixture(scope="module")
def metadata():
    meta_path = os.path.join(PROJECT_ROOT, "models", "pipeline_metadata.json")
    with open(meta_path) as f:
        return json.load(f)


STANDARD_INPUT = {
    "battery_capacity_kWh": 75.0,
    "top_speed_kmh": 180,
    "torque_nm": 430.0,
    "acceleration_0_100_s": 6.5,
    "fast_charging_power_kw_dc": 120.0,
    "towing_capacity_kg": 0.0,
    "cargo_volume_l": 500.0,
    "seats": 5,
    "length_mm": 4700,
    "width_mm": 1850,
    "height_mm": 1600,
    "drivetrain": "FWD",
    "segment": "JC - Medium",
    "car_body_type": "SUV",
    "number_of_cells": 96.0,
}


def _pipeline_direct_prediction(pipeline):
    """Prediction via direct pipeline.predict()."""
    from src.feature_engineering import engineer_features
    df = pd.DataFrame([STANDARD_INPUT])
    df = engineer_features(df)
    return float(pipeline.predict(df)[0])


def _app_style_prediction(pipeline, metadata):
    """Prediction via the app's prepare_input pathway."""
    from src.feature_engineering import engineer_features

    numeric_features = metadata.get("numeric_features", [])
    categorical_features = metadata.get("categorical_features", [])

    row = {}
    for feat in numeric_features + categorical_features:
        row[feat] = STANDARD_INPUT.get(feat, np.nan)

    df = pd.DataFrame([row])
    for col in numeric_features:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = engineer_features(df)
    return float(pipeline.predict(df)[0])


def test_direct_vs_app_prediction_consistent(pipeline, metadata):
    """Direct pipeline prediction matches the app-style preparation path."""
    pred_direct = _pipeline_direct_prediction(pipeline)
    pred_app = _app_style_prediction(pipeline, metadata)

    np.testing.assert_almost_equal(
        pred_direct, pred_app, decimal=2,
        err_msg=f"Prediction mismatch: direct={pred_direct:.2f}, app={pred_app:.2f}"
    )


def test_repeated_predictions_stable(pipeline):
    """Same input produces identical prediction on repeated calls."""
    from src.feature_engineering import engineer_features
    df = pd.DataFrame([STANDARD_INPUT])
    df = engineer_features(df)

    preds = [float(pipeline.predict(df)[0]) for _ in range(5)]
    assert all(p == preds[0] for p in preds), \
        f"Predictions are not deterministic: {preds}"


def test_api_schema_matches_metadata(metadata):
    """API input schema covers all required features."""
    api_path = os.path.join(PROJECT_ROOT, "app", "api.py")
    with open(api_path) as f:
        api_code = f.read()

    # Check that all metadata features are referenced in the API schema
    all_base_features = [
        "battery_capacity_kWh", "top_speed_kmh", "torque_nm",
        "acceleration_0_100_s", "fast_charging_power_kw_dc",
        "towing_capacity_kg", "cargo_volume_l", "seats",
        "length_mm", "width_mm", "height_mm",
        "drivetrain", "car_body_type", "segment",
    ]
    for feat in all_base_features:
        assert feat in api_code, \
            f"API schema missing feature: {feat}"


def test_metrics_files_consistent():
    """final_metrics.json and pipeline_metadata.json report consistent model name."""
    metrics_path = os.path.join(PROJECT_ROOT, "outputs", "metrics", "final_metrics.json")
    meta_path = os.path.join(PROJECT_ROOT, "models", "pipeline_metadata.json")

    with open(metrics_path) as f:
        metrics = json.load(f)
    with open(meta_path) as f:
        meta = json.load(f)

    assert metrics["model"] == meta["final_model_name"], \
        f"Model name mismatch: metrics='{metrics['model']}', metadata='{meta['final_model_name']}'"

"""
TECHTRACK 3.0 — Model Contract Tests

Verifies that the saved pipeline artifact:
  1. Loads successfully
  2. Accepts the expected input schema
  3. Produces numeric predictions
  4. Predictions are within a reasonable physical range
  5. Preprocessing is included in the pipeline
  6. Forbidden features are absent from the pipeline
"""

import os
import sys
import json
import pytest
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "final_ev_range_pipeline.joblib")
META_PATH = os.path.join(PROJECT_ROOT, "models", "pipeline_metadata.json")

FORBIDDEN_FEATURES = {"efficiency_wh_per_km", "range_km", "source_url"}


@pytest.fixture(scope="module")
def pipeline():
    import joblib
    assert os.path.exists(MODEL_PATH), f"Model artifact not found at {MODEL_PATH}"
    return joblib.load(MODEL_PATH)


@pytest.fixture(scope="module")
def metadata():
    assert os.path.exists(META_PATH), f"Metadata not found at {META_PATH}"
    with open(META_PATH) as f:
        return json.load(f)


@pytest.fixture
def sample_input():
    """A realistic mid-range EV specification."""
    from src.feature_engineering import engineer_features
    row = pd.DataFrame([{
        "battery_capacity_kWh": 75.0,
        "top_speed_kmh": 180,
        "torque_nm": 430.0,
        "acceleration_0_100_s": 6.5,
        "fast_charging_power_kw_dc": 120.0,
        "towing_capacity_kg": 0.0,
        "cargo_volume_l": 500.0,
        "seats": 5,
        "length_mm": 4700,
        "width_mm": 1850,
        "height_mm": 1600,
        "drivetrain": "FWD",
        "segment": "JC - Medium",
        "car_body_type": "SUV",
        "number_of_cells": 96.0,
    }])
    return engineer_features(row)


def test_model_loads(pipeline):
    """Pipeline artifact loads without error."""
    assert pipeline is not None


def test_metadata_exists(metadata):
    """Pipeline metadata is present and has required keys."""
    required_keys = [
        "numeric_features", "categorical_features",
        "target", "forbidden_features",
    ]
    for key in required_keys:
        assert key in metadata, f"Missing metadata key: {key}"


def test_prediction_succeeds(pipeline, sample_input):
    """Pipeline produces a prediction for valid input."""
    pred = pipeline.predict(sample_input)
    assert pred is not None
    assert len(pred) == 1


def test_prediction_is_numeric(pipeline, sample_input):
    """Prediction is a numeric value."""
    pred = pipeline.predict(sample_input)
    assert np.isfinite(pred[0]), f"Prediction is not finite: {pred[0]}"
    assert isinstance(float(pred[0]), float)


def test_prediction_is_reasonable(pipeline, sample_input):
    """Prediction is within physically plausible EV range (50-900 km)."""
    pred = pipeline.predict(sample_input)[0]
    assert 50 <= pred <= 900, f"Prediction {pred:.1f} km is outside plausible range"


def test_prediction_positive(pipeline, sample_input):
    """Prediction is positive."""
    pred = pipeline.predict(sample_input)[0]
    assert pred > 0, f"Prediction is non-positive: {pred}"


def test_forbidden_features_absent(metadata):
    """No forbidden feature appears in the model's feature list."""
    all_features = set(
        metadata.get("numeric_features", []) +
        metadata.get("categorical_features", [])
    )
    for forbidden in FORBIDDEN_FEATURES:
        assert forbidden not in all_features, \
            f"LEAKAGE: '{forbidden}' found in pipeline feature list"


def test_pipeline_has_preprocessor(pipeline):
    """Pipeline includes a preprocessing step."""
    # For a standard sklearn Pipeline
    if hasattr(pipeline, "named_steps"):
        assert "preprocessor" in pipeline.named_steps, \
            "Pipeline missing 'preprocessor' step"
    # For ensemble (VotingRegressor wrapping pipelines)
    elif hasattr(pipeline, "estimators_"):
        # Check first estimator
        first = pipeline.estimators_[0]
        if isinstance(first, tuple):
            first = first[1]
        assert hasattr(first, "named_steps") and "preprocessor" in first.named_steps, \
            "Ensemble base estimator missing preprocessor"
    else:
        pytest.fail("Pipeline structure not recognized")


def test_different_inputs_give_different_predictions(pipeline):
    """Model is not degenerate — different specs produce different predictions."""
    from src.feature_engineering import engineer_features

    small_ev = pd.DataFrame([{
        "battery_capacity_kWh": 30.0, "top_speed_kmh": 130,
        "torque_nm": 200.0, "acceleration_0_100_s": 10.0,
        "fast_charging_power_kw_dc": 50.0, "towing_capacity_kg": 0.0,
        "cargo_volume_l": 250.0, "seats": 4, "length_mm": 3800,
        "width_mm": 1700, "height_mm": 1500, "drivetrain": "FWD",
        "segment": "A - Mini", "car_body_type": "Hatchback",
        "number_of_cells": np.nan,
    }])
    large_ev = pd.DataFrame([{
        "battery_capacity_kWh": 120.0, "top_speed_kmh": 250,
        "torque_nm": 800.0, "acceleration_0_100_s": 3.5,
        "fast_charging_power_kw_dc": 270.0, "towing_capacity_kg": 2500.0,
        "cargo_volume_l": 800.0, "seats": 5, "length_mm": 5100,
        "width_mm": 2000, "height_mm": 1700, "drivetrain": "AWD",
        "segment": "F - Luxury", "car_body_type": "SUV",
        "number_of_cells": 216.0,
    }])

    pred_small = pipeline.predict(engineer_features(small_ev))[0]
    pred_large = pipeline.predict(engineer_features(large_ev))[0]

    assert pred_large > pred_small, \
        f"Large EV ({pred_large:.0f}km) should have longer range than small EV ({pred_small:.0f}km)"


def test_handles_missing_values(pipeline):
    """Pipeline handles NaN values gracefully via imputation."""
    from src.feature_engineering import engineer_features

    sparse_input = pd.DataFrame([{
        "battery_capacity_kWh": 75.0, "top_speed_kmh": 180,
        "torque_nm": np.nan, "acceleration_0_100_s": 6.5,
        "fast_charging_power_kw_dc": np.nan, "towing_capacity_kg": np.nan,
        "cargo_volume_l": 500.0, "seats": 5, "length_mm": 4700,
        "width_mm": 1850, "height_mm": 1600, "drivetrain": "FWD",
        "segment": "JC - Medium", "car_body_type": "SUV",
        "number_of_cells": np.nan,
    }])
    pred = pipeline.predict(engineer_features(sparse_input))
    assert np.isfinite(pred[0]), "Pipeline should handle NaN values via imputation"

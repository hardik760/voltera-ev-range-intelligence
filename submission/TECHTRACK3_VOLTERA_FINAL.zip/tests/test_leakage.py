"""
TECHTRACK 3.0 — Target Leakage Tests

These tests MUST FAIL if any forbidden feature enters the predictive pipeline.

Forbidden features:
  - range_km (the target itself)
  - efficiency_wh_per_km (algebraic relationship with target)
  - source_url (unique identifier / metadata)
  - Any target-derived variable

Tests inspect:
  1. Pipeline metadata
  2. Saved pipeline artifact internals
  3. Source code files
  4. Feature engineering registry
"""

import os
import sys
import json
import pytest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

FORBIDDEN_FEATURES = {"efficiency_wh_per_km", "range_km", "source_url"}
SUSPICIOUS_PATTERNS = ["efficiency", "wh_per_km", "range_km"]


@pytest.fixture(scope="module")
def metadata():
    meta_path = os.path.join(PROJECT_ROOT, "models", "pipeline_metadata.json")
    with open(meta_path) as f:
        return json.load(f)


@pytest.fixture(scope="module")
def pipeline():
    import joblib
    model_path = os.path.join(PROJECT_ROOT, "models", "final_ev_range_pipeline.joblib")
    return joblib.load(model_path)


# --- Metadata-level leakage checks ---

def test_no_forbidden_in_numeric_features(metadata):
    """No forbidden feature in the numeric feature list."""
    for feat in metadata.get("numeric_features", []):
        assert feat not in FORBIDDEN_FEATURES, \
            f"LEAKAGE: '{feat}' in numeric_features"


def test_no_forbidden_in_categorical_features(metadata):
    """No forbidden feature in the categorical feature list."""
    for feat in metadata.get("categorical_features", []):
        assert feat not in FORBIDDEN_FEATURES, \
            f"LEAKAGE: '{feat}' in categorical_features"


def test_no_forbidden_in_engineered_features(metadata):
    """No forbidden feature in the engineered feature list."""
    for feat in metadata.get("engineered_features", []):
        for pattern in SUSPICIOUS_PATTERNS:
            assert pattern not in feat.lower(), \
                f"LEAKAGE: engineered feature '{feat}' contains suspicious pattern '{pattern}'"


def test_metadata_declares_forbidden(metadata):
    """Metadata explicitly lists forbidden features."""
    declared = set(metadata.get("forbidden_features", []))
    for f in FORBIDDEN_FEATURES:
        assert f in declared, f"'{f}' should be declared as forbidden in metadata"


# --- Pipeline artifact-level checks ---

def test_pipeline_feature_names_clean(pipeline):
    """Inspect the fitted pipeline for forbidden feature names."""
    # Try to extract feature names from the preprocessor
    feature_names = []
    if hasattr(pipeline, "named_steps") and "preprocessor" in pipeline.named_steps:
        preprocessor = pipeline.named_steps["preprocessor"]
        try:
            feature_names = list(preprocessor.get_feature_names_out())
        except Exception:
            # Fallback: inspect transformer specs
            for name, trans, cols in preprocessor.transformers_:
                if name != "remainder":
                    if isinstance(cols, list):
                        feature_names.extend(cols)
    elif hasattr(pipeline, "estimators_"):
        # Ensemble: check first estimator
        first = pipeline.estimators_[0]
        if isinstance(first, tuple):
            first = first[1]
        if hasattr(first, "named_steps") and "preprocessor" in first.named_steps:
            try:
                feature_names = list(first.named_steps["preprocessor"].get_feature_names_out())
            except Exception:
                for name, trans, cols in first.named_steps["preprocessor"].transformers_:
                    if name != "remainder" and isinstance(cols, list):
                        feature_names.extend(cols)

    for feat in feature_names:
        assert feat not in FORBIDDEN_FEATURES, \
            f"LEAKAGE: forbidden feature '{feat}' found in fitted pipeline"


# --- Source code-level checks ---

def test_no_efficiency_in_preprocessing_code():
    """preprocessing.py does not use efficiency_wh_per_km in feature lists."""
    fpath = os.path.join(PROJECT_ROOT, "src", "preprocessing.py")
    with open(fpath) as f:
        content = f.read()

    # Check feature list definitions
    for line in content.split("\n"):
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith('"""'):
            continue
        if "efficiency_wh_per_km" in stripped:
            # Only acceptable if it's in a comment/docstring or forbidden list
            if "FORBIDDEN" not in stripped and "forbidden" not in stripped \
               and "LEAKAGE" not in stripped and "Policy" not in stripped:
                assert False, \
                    f"LEAKAGE: 'efficiency_wh_per_km' found in active code in preprocessing.py: {stripped}"


def test_no_efficiency_in_modeling_code():
    """modeling.py does not use efficiency_wh_per_km."""
    fpath = os.path.join(PROJECT_ROOT, "src", "modeling.py")
    with open(fpath) as f:
        content = f.read()

    for line in content.split("\n"):
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith('"""'):
            continue
        if "efficiency_wh_per_km" in stripped:
            if "LEAKAGE" not in stripped and "Policy" not in stripped:
                assert False, \
                    f"LEAKAGE: 'efficiency_wh_per_km' found in modeling.py: {stripped}"


# --- Feature engineering registry check ---

def test_feature_registry_inputs_clean():
    """No engineered feature uses a forbidden column as input."""
    from src.feature_engineering import FEATURE_REGISTRY

    for feat in FEATURE_REGISTRY:
        for inp in feat["inputs"]:
            assert inp not in FORBIDDEN_FEATURES, \
                f"LEAKAGE: Feature '{feat['name']}' uses forbidden input '{inp}'"


# --- Automated leakage audit function ---

def test_leakage_audit_passes():
    """The built-in leakage audit function passes."""
    from src.feature_engineering import leakage_audit
    from src.preprocessing import NUMERIC_FEATURES_CORE, ENGINEERED_FEATURES, CATEGORICAL_FEATURES
    import pandas as pd

    # Create a minimal DataFrame with all needed columns
    from src.data_cleaning import clean_data
    df = clean_data(os.path.join(PROJECT_ROOT, "data", "raw"))
    from src.feature_engineering import engineer_features
    df = engineer_features(df)

    all_features = NUMERIC_FEATURES_CORE + ENGINEERED_FEATURES + CATEGORICAL_FEATURES
    result = leakage_audit(df, all_features)
    assert result["passed"], f"Leakage audit FAILED: {result['violations']}"

"""
TECHTRACK 3.0 — Data Quality Tests

Automated checks for:
  1. Required columns exist in raw data
  2. Target column exists and is valid
  3. No invalid/malformed values in critical columns
  4. Preprocessing compatibility
  5. Cleaned data integrity
"""

import os
import sys
import pytest
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

RAW_DATA_PATH = os.path.join(PROJECT_ROOT, "data", "raw", "ev_specs_2025.xls")
CLEANED_DATA_PATH = os.path.join(PROJECT_ROOT, "data", "processed", "ev_data_cleaned.csv")


@pytest.fixture(scope="module")
def raw_df():
    return pd.read_excel(RAW_DATA_PATH)


@pytest.fixture(scope="module")
def cleaned_df():
    return pd.read_csv(CLEANED_DATA_PATH)


# --- Raw data checks ---

REQUIRED_RAW_COLUMNS = [
    "brand", "model", "range_km", "battery_capacity_kWh",
    "top_speed_kmh", "torque_nm", "acceleration_0_100_s",
    "efficiency_wh_per_km", "fast_charging_power_kw_dc",
    "towing_capacity_kg", "cargo_volume_l", "seats",
    "length_mm", "width_mm", "height_mm",
    "drivetrain", "segment", "car_body_type",
]


def test_raw_data_exists():
    """Raw dataset file exists."""
    assert os.path.exists(RAW_DATA_PATH), f"Raw data not found: {RAW_DATA_PATH}"


def test_raw_has_required_columns(raw_df):
    """Raw dataset contains all expected columns."""
    for col in REQUIRED_RAW_COLUMNS:
        assert col in raw_df.columns, f"Missing required column: {col}"


def test_raw_has_expected_rows(raw_df):
    """Raw dataset has 478 rows."""
    assert len(raw_df) == 478, f"Expected 478 rows, got {len(raw_df)}"


def test_target_exists_and_valid(raw_df):
    """Target column range_km exists, is numeric, and has no missing values."""
    assert "range_km" in raw_df.columns
    assert raw_df["range_km"].notna().all(), "Target has missing values"
    assert pd.api.types.is_numeric_dtype(raw_df["range_km"]), "Target is not numeric"


def test_target_range_plausible(raw_df):
    """Target values are within physically plausible range."""
    assert raw_df["range_km"].min() >= 50, f"Min range too low: {raw_df['range_km'].min()}"
    assert raw_df["range_km"].max() <= 1000, f"Max range too high: {raw_df['range_km'].max()}"


def test_battery_capacity_valid(raw_df):
    """Battery capacity is positive and within plausible range."""
    vals = raw_df["battery_capacity_kWh"].dropna()
    assert (vals > 0).all(), "Battery capacity must be positive"
    assert vals.max() <= 250, f"Max battery capacity implausible: {vals.max()}"


def test_no_negative_numeric_values(raw_df):
    """Core numeric specs should not be negative."""
    non_negative_cols = [
        "battery_capacity_kWh", "top_speed_kmh", "range_km",
        "seats", "length_mm", "width_mm", "height_mm",
    ]
    for col in non_negative_cols:
        if col in raw_df.columns:
            vals = raw_df[col].dropna()
            assert (vals >= 0).all(), f"Negative values in {col}"


# --- Cleaned data checks ---

def test_cleaned_data_exists():
    """Cleaned dataset file exists."""
    assert os.path.exists(CLEANED_DATA_PATH), f"Cleaned data not found"


def test_cleaned_no_missing_target(cleaned_df):
    """Cleaned data has no missing target values."""
    assert cleaned_df["range_km"].notna().all()


def test_cleaned_cargo_volume_numeric(cleaned_df):
    """cargo_volume_l is fully numeric after cleaning (no 'Banana Boxes' text)."""
    assert pd.api.types.is_numeric_dtype(cleaned_df["cargo_volume_l"]), \
        "cargo_volume_l should be numeric after cleaning"
    assert cleaned_df["cargo_volume_l"].notna().all(), \
        "cargo_volume_l should have no NaN after cleaning"


def test_cleaned_no_forbidden_columns(cleaned_df):
    """Cleaned data does not contain zero-variance or metadata columns."""
    should_be_dropped = {"battery_type", "source_url", "fast_charge_port"}
    for col in should_be_dropped:
        assert col not in cleaned_df.columns, \
            f"Column '{col}' should have been dropped during cleaning"


def test_cleaned_preserves_all_rows(raw_df, cleaned_df):
    """Cleaning preserves all rows (no records deleted)."""
    assert len(cleaned_df) == len(raw_df), \
        f"Cleaned data has {len(cleaned_df)} rows, raw has {len(raw_df)}"


def test_cleaned_target_matches_raw(raw_df, cleaned_df):
    """Target values are unchanged by cleaning."""
    np.testing.assert_array_equal(
        cleaned_df["range_km"].values,
        raw_df["range_km"].values,
        err_msg="Target values changed during cleaning"
    )


# --- Preprocessing compatibility ---

def test_preprocessing_feature_sets():
    """Feature set definitions are importable and non-empty."""
    from src.preprocessing import NUMERIC_FEATURES_CORE, ENGINEERED_FEATURES, CATEGORICAL_FEATURES
    assert len(NUMERIC_FEATURES_CORE) > 0, "No numeric features defined"
    assert len(ENGINEERED_FEATURES) > 0, "No engineered features defined"
    assert len(CATEGORICAL_FEATURES) > 0, "No categorical features defined"


def test_engineered_features_computable(cleaned_df):
    """All engineered features can be computed from cleaned data."""
    from src.feature_engineering import engineer_features
    df = engineer_features(cleaned_df)
    from src.preprocessing import ENGINEERED_FEATURES
    for feat in ENGINEERED_FEATURES:
        assert feat in df.columns, f"Engineered feature '{feat}' not in output"
        assert df[feat].notna().sum() > 0, f"Engineered feature '{feat}' is all NaN"
